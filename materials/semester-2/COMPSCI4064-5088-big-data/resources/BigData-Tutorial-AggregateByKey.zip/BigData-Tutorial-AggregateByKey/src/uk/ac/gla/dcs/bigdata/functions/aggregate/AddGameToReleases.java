package uk.ac.gla.dcs.bigdata.functions.aggregate;

import org.apache.spark.api.java.function.Function2;

import uk.ac.gla.dcs.bigdata.structures.ReleasesAggregate;
import uk.ac.gla.dcs.bigdata.structures.SteamGameStats;


/**
 * This is what Spark calls a sequence (Seq) function. It adds a record of type R to a pre-existing aggregate A.
 * In this case, we are adding a game (SteamGameStats) to a ReleasesAggregate object that holds the release dates
 * for games.
 * @author richardm
 *
 */
public class AddGameToReleases implements Function2<ReleasesAggregate, SteamGameStats, ReleasesAggregate> {

	private static final long serialVersionUID = -1079577416675185407L;

	@Override
	public ReleasesAggregate call(ReleasesAggregate aggregate, SteamGameStats game) throws Exception {
		
		String date = game.getReleasedate();
		
		if (date!=null) {
			if (!aggregate.getDate2gamecount().containsKey(date)) aggregate.getDate2gamecount().put(date, 1); // if we have not seen this date before, add this game to its count
			else {
				 int newCount = aggregate.getDate2gamecount().get(date) + 1; // else increment count for the day
				 aggregate.getDate2gamecount().put(date, newCount); // ...and update the aggregate
			}
		}
		
		return aggregate;
	}

	
}

