package uk.ac.gla.dcs.bigdata.apps;

import java.io.File;
import java.util.Map;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

import uk.ac.gla.dcs.bigdata.functions.aggregate.AddGameToReleases;
import uk.ac.gla.dcs.bigdata.functions.aggregate.CombineReleases;
import uk.ac.gla.dcs.bigdata.functions.aggregate.GameToTypeGamePair;
import uk.ac.gla.dcs.bigdata.functions.map.SteamStatsFormatter;
import uk.ac.gla.dcs.bigdata.structures.ReleasesAggregate;
import uk.ac.gla.dcs.bigdata.structures.SteamGameStats;

/**
 * Spark Tutorial: Aggregates, illustrates how to combine key-grouped data while changing RDD data types.
 * 
 * Task: Group steam games by type then print the number of games of each type released per day
 *       At the same time, calculate the average the number of non-stopword terms within the game descriptions only for games on Mac
 * @author Richard
 *
 */
public class SparkTutorialAgg {

	/**
	 * Gets the average price for games grouped my metacritic score using map groups
	 * @return
	 */
	public static void main(String[] args) {
		
				// Spark relies on some legacy components of hadoop to manage data input/output, this means we need to
				// give Spark a copy of some hadoop executables, in this case we have included a copy of these in the
				// resources/hadoop/ directory.
				File hadoopDIR = new File("resources/hadoop/"); // represent the hadoop directory as a Java file so we can get an absolute path for it
				System.setProperty("hadoop.home.dir", hadoopDIR.getAbsolutePath()); // set the JVM system property so that Spark finds it
				
				// SparkConf is the configuration for the spark session we are going to create
				// setMaster specifies how we want the application to be run, in this case in local mode with 2 cores
				// setAppName specifies the name of the spark session we will create, this is in effect a unique identifier for our session
				SparkConf conf = new SparkConf()
						.setMaster("local[2]")
						.setAppName("SparkTutorialAgg");
				
				
				// To run a Spark job we need to create a SparkSession, in local mode, this creates a temporary spark cluster
				// on your local machine to run the job on.
				SparkSession spark = SparkSession
						  .builder()
						  .config(conf)
						  .getOrCreate();
						
				// --------------------------------------------------------------------------------------
				// Spark Application Topology Starts Here
				// --------------------------------------------------------------------------------------
				
				//-----------------------------------------
				// Data Input
				//-----------------------------------------
				// Lets read in some statistics of Steam games from a file
				Dataset<Row> steamGamesAsRowTable = spark
						.read()
						.option("header", "true")
						.csv("data/Steam/games_features.sample.csv");

				// Row objects are a general representation of data items in Spark, a Dataset<Row> represents a set of Rows, i.e. its like a Table
				// Dataset<Row> support lots of out-of-the-box transformations using Spark SQL, but as we are more interested in what happens 'under-the-hood'
				// in Spark, we will be converting our Rows to more specialist data types 
				
				
				//-----------------------------------------
				// Data Transformations
				//-----------------------------------------
				
				// As a simple test, lets convert each Row object to a SteamGameStats object, such that we have easier access to get/set methods for each
				
				// Spark needs to understand how to serialise (i.e. package for storage or network transfer) any Java object type we are going to use, since 
				// in a distributed setting our transformations may happen on different machines, or intermediate results may need to be stored between processing
				// stages. We do this by defining an Encoder for the object. In this case, we going to use a new class SteamGameStats, so we need an encoder for it.
				// Encoders.bean() can be used to automatically construct an encoder for an object, so long as the object 1) is not native (e.g. an int or String) and
				// the object is inherently Serializable. If dealing with native Java types then you can use Encoders.<NativeType>(), e.g. Encoders.STRING().
				Encoder<SteamGameStats> steamGameStatsEncoder = Encoders.bean(SteamGameStats.class);
				
				// In Spark, data transformations are specified by calling transformation functions on Datasets
				// The most basic transformation is 'map', this converts each item in the dataset to a new item (that may be of a different type)
				// The map function takes as input two parameters
				//   - A class that implements MapFunction<InputType,OutputType>
				//   - An encoder for the output type (which we just created in the previous step)
				Dataset<SteamGameStats> steamGames = steamGamesAsRowTable.map(new SteamStatsFormatter(), steamGameStatsEncoder);
				
				//-----------------------------------------
				// Tutorial Aggregate Additions
				//-----------------------------------------
				
				// Lets assume that we want to get the number of games published per day for each game type (Singleplayer, Multiplayer, MMO)
				
				// First, we need to group our games based on their type
				// In the previous tutorials, we have used the groupByKey operation, which is supported as part of the Spark SQL API
				// and when used results in a KeyValueGroupedDataset<K,V> (another Spark SQL object). However there is an alternative
				// way of doing this without relying on Spark SQL, which we need in this case as Spark SQL does not support aggregateByKey
				// that we will use later.
				
				// This alternative way is to define a 'PairFunction' which is simply a function that takes as input an object of type A,
				// and returns a Tuple<K,V>. If we want this to act like our groupByKey, then A (input) and V (the value in the output pair) 
				// would be of the same type, although this does not need to be the case. Here we define a pair function that converts from
				// a SteamGameStats object to a Tuple2<String, SteamGameStats> pair.
				GameToTypeGamePair pairFunction = new GameToTypeGamePair();
			
				// Now we can apply this function to our game list to get a new RDD
				// Note that before applying the pairing function I have used 'toJavaRDD()' to convert from a Dataset<SteamGameStats> (which
				// is the Spark SQL RDD format) to JavaRDD<SteamGameStats> (which is the Spark Core RDD format). These two RDD formats have
				// minor differences in the transformations that they support, converting between them is very low cost, as it does not change
				// the underlying data representation. The Spark SQL format is generally a little more user-friendly, hence why we started with it.
				// The Spark SQL format is also what Spark wrappers like PySpark normally use. The core RDD format on the other hand provides access
				// to the underlying operations that can be performed on a raw RDD.
				JavaPairRDD<String, SteamGameStats> platform2games = steamGames.toJavaRDD().mapToPair(pairFunction);
				
				
				// Now that we have our games grouped by game type, you might think it would be as easy as looping over each and counting,
		        // however, if we are to avoid returning the RDD to the driver, we need a method to go from <type,game> pairs
				// (a 1-many relationship) to <type,allReleaseDates> (a 1-1 relationship) in Spark. There are two broad strategies you
				// could go for here. 1) you could convert each game (SteamGameStats) object to a new allReleaseDates object you define,
				// and then perform a pair-wise reduction, however this requires us to create a lot of new objects, which will incur some
				// computational (and later garbage collection) cost. The alternative is to use an aggregation...
				
				// If you recall the slides where we introduced aggregateByKey(), you will remember that this a bit different to the transformations
				// we have looked at so far, in that it actually wants *three* inputs rather than one:
				// - A Java class that can store the intermediate data during aggregation (this is our allReleaseDates), that starts empty
				// - A Function that adds a record into the aggregate, i.e. that takes in a game and allReleaseDates, and returns allReleaseDates with the game added
				// - A Function that combines two aggregates together, i.e. takes allReleaseDates from two different RDD/Dataset partitions and combines them
				
				// Lets start with the aggregate itself
				// This is just a basic java class that holds a dictionary inside it, mapping release dates to the number of games released on that day, it starts empty
				ReleasesAggregate gameReleaseData = new ReleasesAggregate();
				
				// Next we need the function that will allow us to add a game to the aggregate
				AddGameToReleases addGame = new AddGameToReleases();
				
				// Finally we need a function that allows us to combine multiple aggregates together, this is because when parallelized, different executors can work
				// on different aggregates, and so we need to finally combine them to get the complete aggregate
				CombineReleases combineReleases = new CombineReleases();
				
				// Now we can apply the aggregation, this results in only a single ReleasesAggregate per platform
				JavaPairRDD<String, ReleasesAggregate> releaseDatesByType = platform2games.aggregateByKey(gameReleaseData, addGame, combineReleases);

				
				//-----------------------------------------
				// Data Collection at the Driver
				//-----------------------------------------
				
				// Collect our data at the driver as a list (Spark ACTION)
				Map<String, ReleasesAggregate> resultsHashMap = releaseDatesByType.collectAsMap();
				
				// Lets print the results
				for (String platform : resultsHashMap.keySet()) { // for each platform
					for (String date : resultsHashMap.get(platform).getDate2gamecount().keySet()) { // for each date
						System.out.println(platform+" "+date+" "+resultsHashMap.get(platform).getDate2gamecount().get(date));
					}
				}
				
	}
	
}
