package uk.ac.gla.dcs.bigdata.functions.aggregate;

import org.apache.spark.api.java.function.PairFunction;

import scala.Tuple2;
import uk.ac.gla.dcs.bigdata.structures.SteamGameStats;

/**
 * This is an explicit pairing function that converts from a SteamGameStats object to a
 * <String,SteamGameStats> pair, where the string is the game type.
 * 
 * This is an alternative means to create a <Key,Value> based RDD that does not rely on
 * the Spark SQL convenience functions.
 * @author richardm
 *
 */
public class GameToTypeGamePair implements PairFunction<SteamGameStats,String,SteamGameStats>{


	private static final long serialVersionUID = -2769923116266253954L;

	@Override
	public Tuple2<String, SteamGameStats> call(SteamGameStats t) throws Exception {
		
		String type = "Unknown";
		if (t.isCategorysingleplayer()) type = "Single Player";
		if (t.isCategorymultiplayer()) type = "Multiplayer";
		if (t.isCategorymmo()) type = "MMO";
		
		return new Tuple2<String, SteamGameStats>(type, t);
	}

}
