package uk.ac.gla.dcs.bigdata.functions.aggregate;

import org.apache.spark.api.java.function.Function2;

import uk.ac.gla.dcs.bigdata.structures.ReleasesAggregate;

/**
 * This is a Spark Combination (Comb) function, it takes two objects of type A and returns a new object of type A that
 * is the combination of the two. For efficiency, the output does not need to strictly be a new object, you can reuse
 * either of the inputs here.
 * @author richardm
 *
 */
public class CombineReleases implements Function2<ReleasesAggregate, ReleasesAggregate, ReleasesAggregate>{

	private static final long serialVersionUID = -3590081282326490742L;

	@Override
	public ReleasesAggregate call(ReleasesAggregate aggregate1, ReleasesAggregate aggregate2) throws Exception {
		// add all dates to in aggregate 2 to aggregate 1 and return the new larger aggregate 1
		for (String date : aggregate2.getDate2gamecount().keySet()) {
			if (!aggregate1.getDate2gamecount().containsKey(date)) aggregate1.getDate2gamecount().put(date, aggregate2.getDate2gamecount().get(date)); // if date not in aggregate 1 add it
			else {
				 int newCount = aggregate1.getDate2gamecount().get(date) + aggregate2.getDate2gamecount().get(date); // else combine counts for both aggregates
				 aggregate1.getDate2gamecount().put(date, newCount); // ...and update the aggregate
			}
		}
		
		return aggregate1;
	}

}
