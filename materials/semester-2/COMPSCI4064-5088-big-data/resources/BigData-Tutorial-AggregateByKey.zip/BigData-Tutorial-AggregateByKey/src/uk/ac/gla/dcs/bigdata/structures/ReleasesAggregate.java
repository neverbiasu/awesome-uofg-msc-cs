package uk.ac.gla.dcs.bigdata.structures;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * This is simply a dictionary/hash map that provides a mapping between
 * a date name and the number of games published on that date.
 * 
 * Its serializable, so can be used in Spark Functions
 * @author richardm
 *
 */
public class ReleasesAggregate implements Serializable{

	private static final long serialVersionUID = -4651621851692134571L;
	
	Map<String,Integer> date2gamecount;

	public ReleasesAggregate() {
		date2gamecount = new HashMap<String,Integer>();
	}
	
	public ReleasesAggregate(Map<String, Integer> publisher2gamecount) {
		super();
		this.date2gamecount = publisher2gamecount;
	}

	public Map<String, Integer> getDate2gamecount() {
		return date2gamecount;
	}

	public void setDate2gamecount(Map<String, Integer> date2gamecount) {
		this.date2gamecount = date2gamecount;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	
}
